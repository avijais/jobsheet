--
-- Database: `jobsheet`
--

-- --------------------------------------------------------

--
-- Table structure for table `job_sheets`
--

CREATE TABLE `job_sheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `alternate_mobile_no` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(112) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pincode` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_brand` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `model_no` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `imei_1` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `imei_2` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fault` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `battery` tinyint(1) NOT NULL DEFAULT '0',
  `battery_cover` tinyint(1) NOT NULL DEFAULT '0',
  `headset` tinyint(1) NOT NULL DEFAULT '0',
  `mmc` tinyint(1) NOT NULL DEFAULT '0',
  `sim` tinyint(1) NOT NULL DEFAULT '0',
  `target_delivery` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `job_sheets`
--

INSERT INTO `job_sheets` (`id`, `user_id`, `name`, `mobile_no`, `alternate_mobile_no`, `email`, `address`, `district`, `state`, `pincode`, `mobile_brand`, `model_no`, `imei_1`, `imei_2`, `fault`, `battery`, `battery_cover`, `headset`, `mmc`, `sim`, `target_delivery`, `created_at`, `updated_at`) VALUES
(1, 1, 'Avinash', '9839152090', '7042406890', 'avinash@email.com', 'shop no 06', 'sonbhadra', 'uttar pradesh', '231224', 'Nokia', '6020', '111111111111111', '222222222222222', 'fault', 0, 0, 0, 0, 0, '2017-05-20', '2017-05-20 11:53:37', '2017-05-20 11:53:37'),
(2, 1, 'Aman', '9839152091', '7042406891', 'avinash@email.com', 'shop no 06', 'sonbhadra', 'uttar pradesh', '231224', 'Samsung', '6021', '111111111111112', '222222222222222', 'fault', 0, 0, 0, 0, 0, '2017-05-20', '2017-05-20 11:53:37', '2017-05-20 11:53:37'),
(3, 1, 'Kajal', '9839152092', '7042406892', 'avinash@email.com', 'shop no 06', 'sonbhadra', 'uttar pradesh', '231224', 'MI', '6022', '111111111111113', '222222222222222', 'fault', 0, 0, 0, 0, 0, '2017-05-20', '2017-05-20 11:53:37', '2017-05-20 11:53:37'),
(10, 1, 'Agrawal', '9839152093', '7042406893', 'avinash@email.com', 'shop no 06', 'sonbhadra', 'uttar pradesh', '231224', 'Oppo', '6023', '111111111111114', '222222222222222', 'fault', 0, 0, 0, 0, 0, '2017-05-20', '2017-05-20 11:53:37', '2017-05-20 11:53:37');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_02_04_041533_create_tasks_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `name`, `created_at`, `updated_at`) VALUES
(2, 1, 'Task two is added after created jobsheet controller, model, repository, table and route', '2017-03-27 14:12:33', '2017-03-27 14:12:33'),
(3, 1, 'dd', '2017-03-27 14:34:06', '2017-03-27 14:34:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'avi', 'avi@email.com', '$2y$10$xX0pkRGV51mOizC7DzO0WOXGIUN9Ts8FPwMf3hViU9GR76XL5nHsS', NULL, '2017-03-27 13:54:54', '2017-03-27 13:54:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `job_sheets`
--
ALTER TABLE `job_sheets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_user_id_index` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_user_id_index` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `job_sheets`
--
ALTER TABLE `job_sheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
